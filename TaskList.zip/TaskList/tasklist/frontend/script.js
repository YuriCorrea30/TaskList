const API_URL = "http://localhost:3000/api/tarefas";
const formTarefa = document.getElementById("formTarefa");
const listaTarefas = document.getElementById("listaTarefas");

async function carregarTarefas() {
    try {
        const resposta = await fetch(API_URL);
        if (!resposta.ok) throw new Error("Erro ao buscar tarefas.");

        const tarefas = await resposta.json();
        listaTarefas.innerHTML = "";

        if (tarefas.length === 0) {
            listaTarefas.innerHTML = `<div class="alert alert-info">Nenhuma tarefa cadastrada.</div>`;
            return;
        }

        tarefas.forEach(tarefa => {
            const concluida = tarefa.status === "Concluída";
            const card = document.createElement("div");

            card.className = `card card-tarefa shadow-sm ${concluida ? "tarefa-concluida" : ""}`;

            card.innerHTML = `
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h5 class="titulo-tarefa">${tarefa.titulo}</h5>
                            <p class="descricao-tarefa">${tarefa.descricao || "Sem descrição"}</p>
                        </div>
                        <span class="badge ${obterClasseStatus(tarefa.status)}">${tarefa.status}</span>
                    </div>
                    <div class="mt-3">
                        <button class="btn btn-sm btn-success" onclick="concluirTarefa(${tarefa.id_tarefa})">Concluir</button>
                        <button class="btn btn-sm btn-warning" onclick="editarTarefa(${tarefa.id_tarefa})">Editar</button>
                        <button class="btn btn-sm btn-danger" onclick="excluirTarefa(${tarefa.id_tarefa})">Excluir</button>
                    </div>
                </div>
            `;

            listaTarefas.appendChild(card);
        });
    } catch (erro) {
        console.error(erro);
        listaTarefas.innerHTML = `<div class="alert alert-danger">Não foi possível carregar as tarefas.</div>`;
    }
}

function obterClasseStatus(status) {
    if (status === "Concluída") return "bg-success";
    if (status === "Em andamento") return "bg-warning text-dark";
    return "bg-secondary";
}

formTarefa.addEventListener("submit", async evento => {
    evento.preventDefault();

    const titulo = document.getElementById("titulo").value;
    const descricao = document.getElementById("descricao").value;
    const status = document.getElementById("status").value;

    try {
        const resposta = await fetch(API_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ titulo, descricao, status })
        });

        if (!resposta.ok) throw new Error("Erro ao cadastrar tarefa.");

        formTarefa.reset();
        await carregarTarefas();
    } catch (erro) {
        console.error(erro);
        alert("Não foi possível cadastrar a tarefa.");
    }
});

async function concluirTarefa(id) {
    try {
        const respostaBusca = await fetch(`${API_URL}/${id}`);
        const tarefa = await respostaBusca.json();

        const resposta = await fetch(`${API_URL}/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                titulo: tarefa.titulo,
                descricao: tarefa.descricao,
                status: "Concluída"
            })
        });

        if (!resposta.ok) throw new Error("Erro ao concluir tarefa.");

        await carregarTarefas();
    } catch (erro) {
        console.error(erro);
        alert("Não foi possível concluir a tarefa.");
    }
}

async function editarTarefa(id) {
    try {
        const respostaBusca = await fetch(`${API_URL}/${id}`);
        const tarefa = await respostaBusca.json();

        const novoTitulo = prompt("Digite o novo título:", tarefa.titulo);
        if (novoTitulo === null || novoTitulo.trim() === "") return;

        const novaDescricao = prompt("Digite a nova descrição:", tarefa.descricao);

        const resposta = await fetch(`${API_URL}/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                titulo: novoTitulo,
                descricao: novaDescricao || "",
                status: tarefa.status
            })
        });

        if (!resposta.ok) throw new Error("Erro ao editar tarefa.");

        await carregarTarefas();
    } catch (erro) {
        console.error(erro);
        alert("Não foi possível editar a tarefa.");
    }
}

async function excluirTarefa(id) {
    if (!confirm("Tem certeza que deseja excluir esta tarefa?")) return;

    try {
        const resposta = await fetch(`${API_URL}/${id}`, {
            method: "DELETE"
        });

        if (!resposta.ok) throw new Error("Erro ao excluir tarefa.");

        await carregarTarefas();
    } catch (erro) {
        console.error(erro);
        alert("Não foi possível excluir a tarefa.");
    }
}

carregarTarefas();