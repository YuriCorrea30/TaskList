import {
    listarTarefas,
    buscarTarefa,
    criarTarefa,
    atualizarTarefa,
    excluirTarefa
} from "../models/tarefasModel.js";

export async function getTarefas(req, res) {
    try {
        const tarefas = await listarTarefas();

        res.json(tarefas);

    } catch (erro) {
        console.error("ERRO DO BANCO:", erro.message);

        res.status(500).json({
            mensagem: "Erro ao buscar tarefas.",
            erro: erro.message
        });
    }
}

export async function getTarefa(req, res) {
    try {
        const { id } = req.params;

        const tarefa = await buscarTarefa(id);

        if (!tarefa) {
            return res.status(404).json({
                mensagem: "Tarefa não encontrada."
            });
        }

        res.json(tarefa);

    } catch (erro) {
        console.error("ERRO AO BUSCAR TAREFA:", erro.message);

        res.status(500).json({
            mensagem: "Erro ao buscar tarefa."
        });
    }
}

export async function postTarefa(req, res) {
    try {
        const { titulo, descricao, status } = req.body;

        if (!titulo) {
            return res.status(400).json({
                mensagem: "O título da tarefa é obrigatório."
            });
        }

        const tarefa = await criarTarefa(
            titulo,
            descricao || "",
            status || "Pendente"
        );

        res.status(201).json(tarefa);

    } catch (erro) {
        console.error("ERRO AO CADASTRAR:", erro.message);

        res.status(500).json({
            mensagem: "Erro ao cadastrar tarefa."
        });
    }
}

export async function putTarefa(req, res) {
    try {
        const { id } = req.params;
        const { titulo, descricao, status } = req.body;

        if (!titulo) {
            return res.status(400).json({
                mensagem: "O título da tarefa é obrigatório."
            });
        }

        const tarefa = await atualizarTarefa(
            id,
            titulo,
            descricao || "",
            status || "Pendente"
        );

        if (!tarefa) {
            return res.status(404).json({
                mensagem: "Tarefa não encontrada."
            });
        }

        res.json(tarefa);

    } catch (erro) {
        console.error("ERRO AO EDITAR:", erro.message);

        res.status(500).json({
            mensagem: "Erro ao editar tarefa."
        });
    }
}

export async function deleteTarefa(req, res) {
    try {
        const { id } = req.params;

        const tarefa = await excluirTarefa(id);

        if (!tarefa) {
            return res.status(404).json({
                mensagem: "Tarefa não encontrada."
            });
        }

        res.json({
            mensagem: "Tarefa excluída com sucesso.",
            tarefa: tarefa
        });

    } catch (erro) {
        console.error("ERRO AO EXCLUIR:", erro.message);

        res.status(500).json({
            mensagem: "Erro ao excluir tarefa."
        });
    }
}