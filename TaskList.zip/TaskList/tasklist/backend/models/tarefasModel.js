import pool from "../config/database.js";

export async function listarTarefas() {
    const resultado = await pool.query(
        "SELECT * FROM tarefas ORDER BY id_tarefa"
    );

    return resultado.rows;
}

export async function buscarTarefa(id) {
    const resultado = await pool.query(
        "SELECT * FROM tarefas WHERE id_tarefa = $1",
        [id]
    );

    return resultado.rows[0];
}

export async function criarTarefa(
    titulo,
    descricao,
    status
) {
    const resultado = await pool.query(
        `INSERT INTO tarefas
        (titulo, descricao, status)
        VALUES ($1, $2, $3)
        RETURNING *`,
        [
            titulo,
            descricao,
            status
        ]
    );

    return resultado.rows[0];
}

export async function atualizarTarefa(
    id,
    titulo,
    descricao,
    status
) {
    const resultado = await pool.query(
        `UPDATE tarefas
        SET titulo = $1,
            descricao = $2,
            status = $3
        WHERE id_tarefa = $4
        RETURNING *`,
        [
            titulo,
            descricao,
            status,
            id
        ]
    );

    return resultado.rows[0];
}

export async function excluirTarefa(id) {
    const resultado = await pool.query(
        "DELETE FROM tarefas WHERE id_tarefa = $1 RETURNING *",
        [id]
    );

    return resultado.rows[0];
}