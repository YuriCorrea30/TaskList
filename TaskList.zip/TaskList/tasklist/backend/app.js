import express from "express";
import cors from "cors";

import tarefaRoutes from "./routes/tarefaRoutes.js";

const app = express();

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
    res.json({
        mensagem: "API TaskList funcionando!"
    });
});

app.use("/api/tarefas", tarefaRoutes);

export default app;