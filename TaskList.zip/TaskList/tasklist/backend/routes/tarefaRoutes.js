import express from "express";

import {
    getTarefas,
    getTarefa,
    postTarefa,
    putTarefa,
    deleteTarefa
} from "../controllers/tarefasController.js";

const router = express.Router();

router.get("/", getTarefas);

router.get("/:id", getTarefa);

router.post("/", postTarefa);

router.put("/:id", putTarefa);

router.delete("/:id", deleteTarefa);

export default router;