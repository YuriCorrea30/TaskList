CREATE TABLE tarefas (
    id_tarefa SERIAL PRIMARY KEY,
    titulo VARCHAR(100) NOT NULL,
    descricao TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'Pendente',
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO tarefas (titulo, descricao, status)
VALUES
('Estudar JavaScript', 'Revisar funções e arrays', 'Pendente'),
('Fazer atividade', 'Finalizar o projeto TaskList', 'Pendente'),
('Estudar PostgreSQL', 'Praticar comandos SQL', 'Concluída'),
('Fazer incrição para o curso', 'Estudar js', 'Pendente');
SELECT * FROM tarefas;